﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using cs460Final.Models;

namespace cs460Final.Controllers
{
    public class VideoTagsController : Controller
    {
        private V4Context db = new V4Context();

        // GET: VideoTags
        public ActionResult Index()
        {
            var videoTags = db.VideoTags.Include(v => v.Tags).Include(v => v.Video);
            return View(videoTags.ToList());
        }

        // GET: VideoTags/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VideoTags videoTags = db.VideoTags.Find(id);
            if (videoTags == null)
            {
                return HttpNotFound();
            }
            return View(videoTags);
        }

        // GET: VideoTags/Create
        public ActionResult Create()
        {
            ViewBag.TID = new SelectList(db.Tags, "TID", "Name");
            ViewBag.VID = new SelectList(db.Video, "VID", "Title");
            return View();
        }

        // POST: VideoTags/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "VTID,VID,TID")] VideoTags videoTags)
        {
            if (ModelState.IsValid)
            {
                db.VideoTags.Add(videoTags);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.TID = new SelectList(db.Tags, "TID", "Name", videoTags.TID);
            ViewBag.VID = new SelectList(db.Video, "VID", "Title", videoTags.VID);
            return View(videoTags);
        }

        // GET: VideoTags/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VideoTags videoTags = db.VideoTags.Find(id);
            if (videoTags == null)
            {
                return HttpNotFound();
            }
            ViewBag.TID = new SelectList(db.Tags, "TID", "Name", videoTags.TID);
            ViewBag.VID = new SelectList(db.Video, "VID", "Title", videoTags.VID);
            return View(videoTags);
        }

        // POST: VideoTags/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "VTID,VID,TID")] VideoTags videoTags)
        {
            if (ModelState.IsValid)
            {
                db.Entry(videoTags).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.TID = new SelectList(db.Tags, "TID", "Name", videoTags.TID);
            ViewBag.VID = new SelectList(db.Video, "VID", "Title", videoTags.VID);
            return View(videoTags);
        }

        // GET: VideoTags/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VideoTags videoTags = db.VideoTags.Find(id);
            if (videoTags == null)
            {
                return HttpNotFound();
            }
            return View(videoTags);
        }

        // POST: VideoTags/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            VideoTags videoTags = db.VideoTags.Find(id);
            db.VideoTags.Remove(videoTags);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
