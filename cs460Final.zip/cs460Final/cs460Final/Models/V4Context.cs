namespace cs460Final.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class V4Context : DbContext
    {
        public V4Context()
            : base("name=V4Context1")
        {
        }

        public virtual DbSet<Encodings> Encodings { get; set; }
        public virtual DbSet<Tags> Tags { get; set; }
        public virtual DbSet<Video> Video { get; set; }
        public virtual DbSet<VideoTags> VideoTags { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Encodings>()
                .HasMany(e => e.Video)
                .WithRequired(e => e.Encodings)
                .HasForeignKey(e => e.Encoding)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tags>()
                .HasMany(e => e.VideoTags)
                .WithRequired(e => e.Tags)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Video>()
                .HasMany(e => e.VideoTags)
                .WithRequired(e => e.Video)
                .WillCascadeOnDelete(false);
        }
    }
}
