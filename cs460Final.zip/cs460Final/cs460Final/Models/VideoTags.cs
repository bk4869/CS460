namespace cs460Final.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class VideoTags
    {
        [Key]
        public int VTID { get; set; }

        public int VID { get; set; }

        public int TID { get; set; }

        public virtual Tags Tags { get; set; }

        public virtual Video Video { get; set; }
    }
}
