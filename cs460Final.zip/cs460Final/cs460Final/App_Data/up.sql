
CREATE TABLE [dbo].[Encodings]
(
	EID			INT IDENTITY (1,1) NOT NULL,
	Codec		NVARCHAR(20) NOT NULL,
	CONSTRAINT [PK_dbo.Encodings] PRIMARY KEY CLUSTERED (EID ASC)
);

CREATE TABLE [dbo].[Video]
(
	VID			INT IDENTITY (1,1) NOT NULL,
	Title		NVARCHAR(50)	   NOT NULL,
	Description NVARCHAR(200)	   NOT NULL,
	FrameRate   INT				   NOT NULL,
	Encoding	INT	   NOT NULL,
	CONSTRAINT [PK_dbo.Video] PRIMARY KEY CLUSTERED (VID ASC),
	CONSTRAINT [FK_dbo.Video] FOREIGN KEY (Encoding) REFERENCES [dbo].[Encodings] (EID)


);

CREATE TABLE [dbo].[Tags]
(
	TID			INT IDENTITY (1,1) NOT NULL,
	Name		NVARCHAR(30) NOT NULL,
	CONSTRAINT [PK_dbo.Item] PRIMARY KEY CLUSTERED (TID ASC),
);

CREATE TABLE [dbo].[VideoTags]
(
	VTID INT IDENTITY (1,1) NOT NULL,
	VID INT NOT NULL,
	TID INT NOT NULL,
	CONSTRAINT [PK_dbo.VideoTags] PRIMARY KEY CLUSTERED (VTID ASC),
	CONSTRAINT [FK_dbo.VideoTags] FOREIGN KEY (VID) REFERENCES [dbo].[Video] (VID),
	CONSTRAINT [FK2_dbo.VideoTags] FOREIGN KEY (TID) REFERENCES [dbo].[Tags] (TID)

);

INSERT INTO [dbo].[Encodings] (Name) VALUES
('MP4'),
('OGG'),
('WEBM'),
('H.264');

INSERT INTO dbo.Tags (Name) VALUES
('music'),
('pixar'),
('baby'),
('fortnite'),
('aimbot'),
('animated');

INSERT INTO dbo.Video (Title, Description, FrameRate, Encoding) VALUES
('Ariana Grande - thank u, next',                       'thank u, next (Official Video)',   24, 1),
('Incredible 2 - Edna & Jack-Jack Deleted Scenes',      'Thanks for watching my channel',   60, 4),
('Using Aimbot In A 3v1 Against Playground Squeakers',  'Thank you to Uyrifx for the amazing intro! His instagram name is @uyrifx if you want an amazing intro like ours (good price)! He has done great work, even some intros for Fortnite Poggers!', 120, 3);


INSERT INTO dbo.VideoTags (VID, TID) VALUES
(3,12),(3,13),(2,11),(4,14),(2,16);