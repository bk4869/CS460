﻿
$("selectList").click(function () {

    val tagName 

});